"""
AWS Lambda Function for Certificate Generation
Main handler for processing certificate generation requests from WordPress.
"""

import json
import logging
import os
from datetime import datetime
from certificate_generator import CertificateGenerator

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """
    Main Lambda handler function for certificate generation.
    
    Args:
        event: API Gateway event containing certificate request data
        context: Lambda runtime context
        
    Returns:
        dict: Response with certificate URL and details
    """
    try:
        # Log the incoming request
        logger.info(f"Certificate generation request received: {json.dumps(event)}")
        
        # Parse the request body
        if 'body' in event:
            if isinstance(event['body'], str):
                body = json.loads(event['body'])
            else:
                body = event['body']
        else:
            body = event
            
        # Validate required fields
        required_fields = ['recipient_name', 'course_title', 'tier_level', 'completion_date', 'user_id', 'course_id']
        missing_fields = [field for field in required_fields if field not in body or not body[field]]
        
        if missing_fields:
            logger.error(f"Missing required fields: {missing_fields}")
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'success': False,
                    'error': f'Missing required fields: {", ".join(missing_fields)}'
                })
            }
        
        # Validate tier level
        if body['tier_level'] not in [1, 2, 3]:
            logger.error(f"Invalid tier level: {body['tier_level']}")
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'success': False,
                    'error': 'tier_level must be 1, 2, or 3'
                })
            }
        
        # Generate certificate number
        certificate_number = generate_certificate_number()
        
        # Map tier level to tier name
        tier_names = {
            1: "Foundation Program",
            2: "Mastery Program", 
            3: "Elite Program"
        }
        tier_name = tier_names[body['tier_level']]
        
        # Format completion date
        try:
            completion_date_obj = datetime.strptime(body['completion_date'], '%Y-%m-%d')
            formatted_date = completion_date_obj.strftime('%B %d, %Y')
        except ValueError:
            logger.error(f"Invalid date format: {body['completion_date']}")
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'success': False,
                    'error': 'completion_date must be in YYYY-MM-DD format'
                })
            }
        
        # Prepare certificate data
        certificate_data = {
            'recipient_name': body['recipient_name'].strip(),
            'course_title': body['course_title'].strip(),
            'tier_level': body['tier_level'],
            'tier_name': tier_name,
            'completion_date': formatted_date,
            'certificate_number': certificate_number,
            'user_id': body['user_id'],
            'course_id': body['course_id']
        }
        
        # Initialize certificate generator
        generator = CertificateGenerator()
        
        # Generate the certificate PDF and upload to S3
        result = generator.generate_certificate(certificate_data)
        
        if not result['success']:
            logger.error(f"Certificate generation failed: {result['error']}")
            return {
                'statusCode': 500,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'success': False,
                    'error': result['error']
                })
            }
        
        # Log successful generation
        logger.info(f"Certificate generated successfully: {certificate_number}")
        
        # Return success response
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'success': True,
                'certificate_url': result['certificate_url'],
                'certificate_number': certificate_number,
                'message': f'Certificate generated successfully for {body["recipient_name"]}'
            })
        }
        
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in request body: {str(e)}")
        return {
            'statusCode': 400,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'success': False,
                'error': 'Invalid JSON in request body'
            })
        }
        
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}", exc_info=True)
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'success': False,
                'error': 'Internal server error occurred while generating certificate'
            })
        }

def generate_certificate_number():
    """
    Generate a unique certificate number in format CERT-YYYY-####
    
    Returns:
        str: Certificate number (e.g., CERT-2024-0847)
    """
    import random
    
    current_year = datetime.now().year
    random_number = random.randint(1, 9999)
    
    return f"CERT-{current_year}-{random_number:04d}"

def validate_environment():
    """
    Validate that required environment variables are set.
    
    Returns:
        dict: Validation result with success status and missing variables
    """
    required_env_vars = ['S3_BUCKET', 'S3_REGION']
    missing_vars = []
    
    for var in required_env_vars:
        if not os.getenv(var):
            missing_vars.append(var)
    
    return {
        'success': len(missing_vars) == 0,
        'missing_vars': missing_vars
    }

# Validate environment on import
env_validation = validate_environment()
if not env_validation['success']:
    logger.warning(f"Missing environment variables: {env_validation['missing_vars']}")