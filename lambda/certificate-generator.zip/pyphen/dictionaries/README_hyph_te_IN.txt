This Telugu Hyphenation Dictionary was created by
Santhosh Thottingal, Openoffice Indic Regional Language group.
If you find incorrectly hyphenated words you can submit them
to santhosh.thottingal@gmail.com

*********************************
* Copyright			*
*********************************

Copyright © 2009 Santhosh Thottingal

******* BEGIN LICENSE BLOCK *******
* 
* The Telugu Hyphenation Dictionary may be used under the terms 
* of either the GNU General Public License Version 3 or later (the "GPL"), or
* the GNU Lesser General Public License Version 3 or later (the "LGPL")
*
* Software distributed under the License is distributed on an "AS IS" basis,
* WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
* for the specific language governing rights and limitations under the
* License.
* 

******* END LICENSE BLOCK *******
