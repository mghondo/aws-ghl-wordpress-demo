############################################################

Belarusian Hyphenation Dictionary
Created by: Aleś Bułojčyk <alex73mail@gmail.com>

Hyphenation rules according to official orthography 2008
License: CC BY-SA 4.0 or LGPLv3

############################################################
